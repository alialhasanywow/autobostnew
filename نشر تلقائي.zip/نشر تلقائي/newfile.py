import requests
import subprocess
import tempfile
from urllib.parse import urlparse

def run_python_files_from_github(repo_url):
    # الحصول على محتويات المستودع عبر GitHub API
    parsed_url = urlparse(repo_url)
    path_parts = parsed_url.path.strip('/').split('/')
    
    if len(path_parts) < 2:
        print("رابط المستودع غير صحيح")
        return
    
    owner, repo = path_parts[:2]
    api_url = f"https://api.github.com/repos/{owner}/{repo}/contents/"
    
    try:
        response = requests.get(api_url)
        response.raise_for_status()
        contents = response.json()
        
        for item in contents:
            if item['name'].endswith('.py'):  # تشغيل ملفات بايثون فقط
                print(f"\nجارٍ تشغيل ملف: {item['name']}")
                
                # جلب محتوى الملف
                file_content = requests.get(item['download_url']).text
                
                # إنشاء ملف مؤقت وتشغيله
                with tempfile.NamedTemporaryFile(suffix='.py', delete=False) as temp_file:
                    temp_file.write(file_content.encode('utf-8'))
                    temp_file_path = temp_file.name
                
                # تشغيل الملف باستخدام مترجم بايثون
                result = subprocess.run(['python', temp_file_path], 
                                      capture_output=True, 
                                      text=True)
                
                # عرض النتائج
                print("الإخراج:")
                print(result.stdout)
                if result.stderr:
                    print("الأخطاء:")
                    print(result.stderr)
                
                # حذف الملف المؤقت
                import os
                os.unlink(temp_file_path)
    
    except Exception as e:
        print(f"حدث خطأ: {str(e)}")

# مثال للاستخدام
repo_url = "https://github.com/alialhasanywow/alialhasany"
run_python_files_from_github(repo_url)